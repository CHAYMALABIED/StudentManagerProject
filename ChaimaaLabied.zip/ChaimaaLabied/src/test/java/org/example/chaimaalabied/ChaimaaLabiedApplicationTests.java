package org.example.chaimaalabied;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChaimaaLabiedApplicationTests {

	@Test
	void contextLoads() {
	}

}
