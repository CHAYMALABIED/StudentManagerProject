package org.example.chaimaalabied.mapper;

import org.example.chaimaalabied.dao.entities.Student;
import org.example.chaimaalabied.dto.StudentDTO;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;



@Component
public class StudentMapper {

    private final ModelMapper mapper = new ModelMapper();

    // Method to map from StudentDto to Student
    public Student fromStudentDtoToStudent(StudentDTO  studentDto) {
        return mapper.map(studentDto, Student.class);
    }

    // Method to map from Student to StudentDto
    public StudentDTO fromStudentToStudentDto(Student student) {
        return mapper.map(student, StudentDTO .class);
    }
}
