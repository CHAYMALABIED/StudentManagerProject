package org.example.chaimaalabied;

import org.example.chaimaalabied.dto.StudentDTO;
import org.example.chaimaalabied.service.StudentService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.List;

@SpringBootApplication
public class ChaimaaLabiedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChaimaaLabiedApplication.class, args);
	}
	@Bean
	CommandLineRunner start(StudentService studentService) {
		return args -> {
			studentService.saveStudents(
					List.of(
							StudentDTO.builder()
									.name("mohamed labied")
									.email("mohamedlabied@example.com")
									.dateDeNaissance("1995-05-20")
									.build(),
							StudentDTO.builder()
									.name("sara labied")
									.email("saralabied@example.com")
									.dateDeNaissance("1991-01-19")
									.build(),
							StudentDTO.builder()
									.name("hajar labied")
									.email("hajarlabied@example.com")
									.dateDeNaissance("2000-01-10")
									.build(),
							StudentDTO.builder()
									.name("Fatima Zahra")
									.email("fatimaezzahralabied@example.com")
									.dateDeNaissance("1998-12-25")
									.build()
					)
			);
		};
	}
}
