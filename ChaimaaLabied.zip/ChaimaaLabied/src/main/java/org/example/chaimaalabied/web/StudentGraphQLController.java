package org.example.chaimaalabied.web;
import lombok.AllArgsConstructor;
import org.example.chaimaalabied.dto.StudentDTO;
import org.example.chaimaalabied.service.StudentService;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
@AllArgsConstructor
public class StudentGraphQLController {

    private final StudentService studentService;

    @MutationMapping
    public StudentDTO saveStudent(@Argument StudentDTO student) {
        return studentService.saveStudent(student);
    }
    @QueryMapping
    public List<StudentDTO > getStudentsByDateDeNaissance(@Argument String dateDeNaissance) {
        return studentService.getStudentsByDateDeNaissance(dateDeNaissance);
    }
}
