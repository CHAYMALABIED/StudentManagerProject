package org.example.chaimaalabied.dto;

import lombok.*;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class StudentDTO {
    String name;
    String email;
    String dateDeNaissance;

}
