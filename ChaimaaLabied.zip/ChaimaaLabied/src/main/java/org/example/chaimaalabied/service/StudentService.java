package org.example.chaimaalabied.service;
import org.example.chaimaalabied.dto.StudentDTO;
import java.util.List;

public interface StudentService {

    StudentDTO saveStudent(StudentDTO studentDto);
    // Find students by date of birth
    List<StudentDTO> getStudentsByDateDeNaissance(String dateDeNaissance);

    // Save a list of students
    List<StudentDTO> saveStudents(List<StudentDTO> studentDtos);
}




