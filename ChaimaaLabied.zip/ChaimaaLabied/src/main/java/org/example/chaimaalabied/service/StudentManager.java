package org.example.chaimaalabied.service;
import lombok.AllArgsConstructor;
import org.example.chaimaalabied.dao.entities.Student;
import org.example.chaimaalabied.dao.repositories.StudentRepository;
import org.example.chaimaalabied.dto.StudentDTO;
import org.example.chaimaalabied.mapper.StudentMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;


import java.util.List;

@Service
@AllArgsConstructor
public class StudentManager implements StudentService {

    private StudentRepository studentRepository;
    private StudentMapper studentMapper;

    @Override
    public StudentDTO saveStudent(StudentDTO studentDto) {
        // Map DTO to entity
        Student student = studentMapper.fromStudentDtoToStudent(studentDto);

        // Save entity to the repository
        student = studentRepository.save(student);

        // Map entity back to DTO and return
        return studentMapper.fromStudentToStudentDto(student);
    }


    @Override
    public List<StudentDTO> getStudentsByDateDeNaissance(String dateDeNaissance) {
        List<Student> students = studentRepository.findByDateDeNaissance(dateDeNaissance);
        List<StudentDTO> studentDtos = new ArrayList<>();
        for (Student student : students) {
            studentDtos.add(studentMapper.fromStudentToStudentDto(student));
        }
        return studentDtos;
    }



    @Override
    public List<StudentDTO > saveStudents(List<StudentDTO > studentDtos) {
        // Convert DTOs to entities
        List<Student> students = new ArrayList<>();
        for (StudentDTO  studentDto : studentDtos) {
            students.add(studentMapper.fromStudentDtoToStudent(studentDto));
        }

        // Save all students
        students = studentRepository.saveAll(students);

        // Convert entities back to DTOs and return
        List<StudentDTO > savedStudentDtos = new ArrayList<>();
        for (Student student : students) {
            savedStudentDtos.add(studentMapper.fromStudentToStudentDto(student));
        }
        return savedStudentDtos;
    }
}
